import uuid
from app.models import User


class UserRepository:
    def __init__(self, conn):
        self.conn = conn

    def create(self, name, id=None):
        uid = id or str(uuid.uuid4())
        self.conn.execute(
            "INSERT INTO users (id, name, withdrawable_balance) VALUES (?, ?, 0)",
            (uid, name),
        )
        return self.get(uid)

    def get(self, user_id):
        row = self.conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return User(**dict(row)) if row else None

    def list_all(self):
        rows = self.conn.execute("SELECT * FROM users").fetchall()
        return [User(**dict(r)) for r in rows]

    def get_balance_for_update(self, user_id):
        """Read balance inside an already-open IMMEDIATE transaction.
        SQLite's IMMEDIATE lock at BEGIN already serializes writers, so a
        plain SELECT here is safe from lost updates (unlike autocommit mode)."""
        row = self.conn.execute(
            "SELECT withdrawable_balance FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if row is None:
            raise ValueError(f"User {user_id} not found")
        return row["withdrawable_balance"]

    def adjust_balance(self, user_id, delta_paise):
        """Atomically adjust balance and return the new balance."""
        self.conn.execute(
            "UPDATE users SET withdrawable_balance = withdrawable_balance + ? WHERE id = ?",
            (delta_paise, user_id),
        )
        row = self.conn.execute(
            "SELECT withdrawable_balance FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        return row["withdrawable_balance"]
