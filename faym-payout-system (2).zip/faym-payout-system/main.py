"""
Entrypoint. Initializes the DB (fresh, per the reference data in the
assignment) and starts the Flask dev server.

Run:
    python main.py
Then, e.g.:
    curl http://localhost:5000/health
"""
from app.db import init_db, get_connection
from app.repositories.user_repository import UserRepository
from app.repositories.sale_repository import SaleRepository
from app.models import paise
from app.api import app


def seed():
    init_db(reset=True)
    conn = get_connection()
    conn.execute("INSERT INTO brands (id, name) VALUES ('brand_1','brand_1'),('brand_2','brand_2'),('brand_3','brand_3')")
    user = UserRepository(conn).create(name="John Doe", id="john_doe")
    SaleRepository(conn).create(user_id=user.id, brand_id="brand_1", earning_paise=paise(40))
    conn.commit() if hasattr(conn, "commit") else None
    conn.close()


if __name__ == "__main__":
    seed()
    app.run(debug=True, port=5000)
