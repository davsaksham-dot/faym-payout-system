"""
Mock payment gateway.

In production this would call an external payout provider (Razorpay,
Cashfree, etc.) over HTTP and the result would often arrive asynchronously
via a webhook rather than a synchronous return value. The service layer
is written so that swapping this mock for an async webhook-driven flow
only requires calling `finalize_advance_payout` / `update_withdrawal_status`
from the webhook handler instead of inline — the CAS-guarded repository
methods make both call patterns equally safe.
"""
import random


class PaymentGateway:
    def __init__(self, failure_rate=0.0, force_result=None):
        self.failure_rate = failure_rate
        self.force_result = force_result  # override for deterministic tests: True/False

    def transfer(self, user_id, amount_paise, reference):
        if self.force_result is not None:
            return self.force_result
        return random.random() >= self.failure_rate
