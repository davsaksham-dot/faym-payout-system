import uuid
from app.models import Withdrawal


class WithdrawalRepository:
    def __init__(self, conn):
        self.conn = conn

    def create(self, user_id, amount_paise, id=None, created_at=None):
        wid = id or str(uuid.uuid4())
        if created_at:
            self.conn.execute(
                "INSERT INTO withdrawals (id, user_id, amount, status, created_at, updated_at) "
                "VALUES (?, ?, ?, 'initiated', ?, ?)",
                (wid, user_id, amount_paise, created_at, created_at),
            )
        else:
            self.conn.execute(
                "INSERT INTO withdrawals (id, user_id, amount, status) VALUES (?, ?, ?, 'initiated')",
                (wid, user_id, amount_paise),
            )
        return self.get(wid)

    def get(self, withdrawal_id):
        row = self.conn.execute("SELECT * FROM withdrawals WHERE id = ?", (withdrawal_id,)).fetchone()
        return Withdrawal(**dict(row)) if row else None

    def list_by_user(self, user_id):
        rows = self.conn.execute(
            "SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC", (user_id,)
        ).fetchall()
        return [Withdrawal(**dict(r)) for r in rows]

    def most_recent_rate_limited(self, user_id):
        """
        The most recent withdrawal that counts against the 24h rate limit.
        Only 'initiated' or 'success' withdrawals count — a withdrawal that
        ended up failed/cancelled/rejected (and was recovered) must NOT
        block the user's next attempt (see Q2: recovered funds must be
        immediately re-withdrawable).
        """
        row = self.conn.execute(
            """SELECT * FROM withdrawals WHERE user_id = ? AND status IN ('initiated','success')
               ORDER BY created_at DESC LIMIT 1""",
            (user_id,),
        ).fetchone()
        return Withdrawal(**dict(row)) if row else None

    def try_update_status(self, withdrawal_id, new_status, from_statuses):
        """CAS: only transition if current status is one of `from_statuses`."""
        placeholders = ",".join("?" for _ in from_statuses)
        cur = self.conn.execute(
            f"""UPDATE withdrawals SET status = ?, updated_at = STRFTIME('%Y-%m-%dT%H:%M:%fZ','now')
                WHERE id = ? AND status IN ({placeholders})""",
            (new_status, withdrawal_id, *from_statuses),
        )
        return cur.rowcount == 1

    def try_mark_recovered(self, withdrawal_id):
        """CAS guard so a failed payout's amount is only ever re-credited once,
        even if the failure webhook is delivered more than once."""
        cur = self.conn.execute(
            "UPDATE withdrawals SET recovered = 1 WHERE id = ? AND recovered = 0",
            (withdrawal_id,),
        )
        return cur.rowcount == 1
