"""
Database connection helper.

Uses SQLite for portability (zero setup) but every write path uses
`BEGIN IMMEDIATE` transactions + compare-and-swap UPDATEs, so the same
locking discipline would map cleanly onto Postgres/MySQL
(`SELECT ... FOR UPDATE` or optimistic version columns) in production.
"""
import os
import sqlite3
from contextlib import contextmanager

DB_PATH = os.environ.get("FAYM_DB_PATH", os.path.join(os.path.dirname(__file__), "..", "faym.db"))


def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)  # autocommit; we manage txns manually
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def transaction(conn):
    """
    Explicit IMMEDIATE transaction so concurrent writers block on the
    write-lock instead of racing (SQLite's default deferred mode can
    otherwise allow two writers to both pass a read-check before either
    writes, defeating a naive CAS).
    """
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def init_db(reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = get_connection()
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with open(schema_path) as f:
        conn.executescript(f.read())
    conn.close()
