"""
REST API layer (Flask). Thin controllers only — all business logic lives
in app/services/*. Each request opens its own SQLite connection so
requests don't share (and block on) a single global connection.
"""
from flask import Flask, request, jsonify
from app.db import get_connection
from app.models import paise
from app.repositories.user_repository import UserRepository
from app.repositories.sale_repository import SaleRepository
from app.repositories.withdrawal_repository import WithdrawalRepository
from app.repositories.ledger_repository import LedgerRepository
from app.services.advance_payout_service import AdvancePayoutService
from app.services.reconciliation_service import ReconciliationService
from app.services.withdrawal_service import WithdrawalService
from app.services.payment_gateway import PaymentGateway

app = Flask(__name__)
gateway = PaymentGateway()  # swap for a real gateway client in production


def error_response(e, code=400):
    return jsonify({"error": str(e)}), code


# ---------------------------------------------------------------- Users ----

@app.post("/users")
def create_user():
    body = request.get_json(force=True)
    conn = get_connection()
    try:
        user = UserRepository(conn).create(name=body["name"])
        return jsonify(user.to_dict()), 201
    finally:
        conn.close()


@app.get("/users/<user_id>")
def get_user(user_id):
    conn = get_connection()
    try:
        user = UserRepository(conn).get(user_id)
        if not user:
            return error_response("User not found", 404)
        return jsonify(user.to_dict())
    finally:
        conn.close()


@app.get("/users/<user_id>/transactions")
def get_user_ledger(user_id):
    conn = get_connection()
    try:
        entries = LedgerRepository(conn).list_by_user(user_id)
        return jsonify([e.to_dict() for e in entries])
    finally:
        conn.close()


# ---------------------------------------------------------------- Sales ----

@app.post("/sales")
def create_sale():
    body = request.get_json(force=True)
    conn = get_connection()
    try:
        sale = SaleRepository(conn).create(
            user_id=body["user_id"],
            brand_id=body["brand_id"],
            earning_paise=paise(body["earning"]),
        )
        return jsonify(sale.to_dict()), 201
    finally:
        conn.close()


@app.get("/sales/<sale_id>")
def get_sale(sale_id):
    conn = get_connection()
    try:
        sale = SaleRepository(conn).get(sale_id)
        if not sale:
            return error_response("Sale not found", 404)
        return jsonify(sale.to_dict())
    finally:
        conn.close()


@app.get("/users/<user_id>/sales")
def list_user_sales(user_id):
    conn = get_connection()
    try:
        sales = SaleRepository(conn).list_by_user(user_id)
        return jsonify([s.to_dict() for s in sales])
    finally:
        conn.close()


# ------------------------------------------------------- Admin actions ----

@app.post("/admin/sales/<sale_id>/reconcile")
def reconcile_sale(sale_id):
    body = request.get_json(force=True)
    decision = body["decision"]  # "approved" | "rejected"
    conn = get_connection()
    try:
        result = ReconciliationService(conn).reconcile_and_settle(sale_id, decision)
        return jsonify(result)
    except ValueError as e:
        return error_response(e, 409)
    finally:
        conn.close()


@app.post("/jobs/advance-payout/run")
def run_advance_payout_job():
    """Trigger the advance-payout batch job (would normally be a cron/queue worker)."""
    conn = get_connection()
    try:
        results = AdvancePayoutService(conn, gateway).run_batch()
        return jsonify(results)
    finally:
        conn.close()


@app.post("/jobs/settlement/run")
def run_settlement_sweep():
    """Background sweep to catch any reconciled-but-unsettled sales."""
    conn = get_connection()
    try:
        results = ReconciliationService(conn).settle_unsettled()
        return jsonify(results)
    finally:
        conn.close()


# ------------------------------------------------------------ Withdrawals ---

@app.post("/users/<user_id>/withdrawals")
def initiate_withdrawal(user_id):
    body = request.get_json(force=True)
    conn = get_connection()
    try:
        withdrawal = WithdrawalService(conn).initiate_withdrawal(user_id, paise(body["amount"]))
        return jsonify(withdrawal.to_dict()), 201
    except PermissionError as e:
        return error_response(e, 429)
    except ValueError as e:
        return error_response(e, 400)
    finally:
        conn.close()


@app.get("/users/<user_id>/withdrawals")
def list_withdrawals(user_id):
    conn = get_connection()
    try:
        withdrawals = WithdrawalRepository(conn).list_by_user(user_id)
        return jsonify([w.to_dict() for w in withdrawals])
    finally:
        conn.close()


@app.post("/webhooks/withdrawals/<withdrawal_id>/status")
def withdrawal_status_webhook(withdrawal_id):
    """Simulates the payout-provider callback: success | failed | cancelled | rejected."""
    body = request.get_json(force=True)
    conn = get_connection()
    try:
        result = WithdrawalService(conn).update_withdrawal_status(withdrawal_id, body["status"])
        return jsonify(result)
    except ValueError as e:
        return error_response(e, 400)
    finally:
        conn.close()


@app.get("/health")
def health():
    return jsonify({"status": "ok"})
