"""
Reproduces the assignment's worked example end-to-end and asserts the
final numbers match exactly:

    3 sales, john_doe, brand_1, ₹40 earning each, all pending
    -> Advance payout job runs -> each gets 10% = ₹4 advance
    -> Reconciliation: sale 1 rejected, sale 2 approved, sale 3 approved
    -> Expected final payout: -4 + 36 + 36 = ₹68

Also covers:
    - Idempotency of the advance payout job (running it twice doesn't
      double-pay)
    - The 24h withdrawal rate limit
    - Failed payout recovery (Question 2)
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.db import init_db, get_connection
from app.models import paise, rupees
from app.repositories.user_repository import UserRepository
from app.repositories.sale_repository import SaleRepository
from app.repositories.withdrawal_repository import WithdrawalRepository
from app.services.advance_payout_service import AdvancePayoutService
from app.services.reconciliation_service import ReconciliationService
from app.services.withdrawal_service import WithdrawalService
from app.services.payment_gateway import PaymentGateway


class TestAssignmentExampleScenario(unittest.TestCase):
    def setUp(self):
        os.environ["FAYM_DB_PATH"] = "/tmp/faym_test.db"
        init_db(reset=True)
        self.conn = get_connection()
        self.conn.execute("INSERT INTO brands (id, name) VALUES ('brand_1','brand_1')")
        self.user = UserRepository(self.conn).create(name="John Doe", id="john_doe")
        self.sale_repo = SaleRepository(self.conn)
        self.gateway = PaymentGateway(force_result=True)  # always succeed

    def tearDown(self):
        self.conn.close()
        if os.path.exists("/tmp/faym_test.db"):
            os.remove("/tmp/faym_test.db")

    def test_worked_example_from_assignment(self):
        # --- Before Reconciliation: 3 pending sales of ₹40 each ---
        sale1 = self.sale_repo.create(self.user.id, "brand_1", paise(40))
        sale2 = self.sale_repo.create(self.user.id, "brand_1", paise(40))
        sale3 = self.sale_repo.create(self.user.id, "brand_1", paise(40))

        # --- Advance payout job runs: 10% of each ₹40 = ₹4 ---
        AdvancePayoutService(self.conn, self.gateway).run_batch()

        for sid in (sale1.id, sale2.id, sale3.id):
            s = self.sale_repo.get(sid)
            self.assertEqual(s.advance_payout_status, "paid")
            self.assertEqual(rupees(s.advance_payout_amount), 4.0)

        user = UserRepository(self.conn).get(self.user.id)
        self.assertEqual(rupees(user.withdrawable_balance), 12.0)  # 3 x ₹4

        # --- Running the advance-payout job again must NOT double-pay ---
        AdvancePayoutService(self.conn, self.gateway).run_batch()
        user = UserRepository(self.conn).get(self.user.id)
        self.assertEqual(rupees(user.withdrawable_balance), 12.0)

        # --- Reconciliation: sale1 rejected, sale2 & sale3 approved ---
        recon = ReconciliationService(self.conn)
        r1 = recon.reconcile_and_settle(sale1.id, "rejected")
        r2 = recon.reconcile_and_settle(sale2.id, "approved")
        r3 = recon.reconcile_and_settle(sale3.id, "approved")

        self.assertEqual(rupees(r1["adjustment_paise"]), -4.0)
        self.assertEqual(rupees(r2["adjustment_paise"]), 36.0)
        self.assertEqual(rupees(r3["adjustment_paise"]), 36.0)

        # --- The doc's "Total Final Payout" (-4 + 36 + 36 = 68) is the sum
        # of the settlement ADJUSTMENTS, i.e. money moved during
        # reconciliation on top of the advances already paid out. ---
        total_adjustment = r1["adjustment_paise"] + r2["adjustment_paise"] + r3["adjustment_paise"]
        self.assertEqual(rupees(total_adjustment), 68.0)

        # The user's actual wallet balance is advances-already-paid (₹12)
        # plus those adjustments (₹68) = ₹80 — which correctly equals the
        # true economic value: ₹0 (rejected) + ₹40 (approved) + ₹40 (approved).
        user = UserRepository(self.conn).get(self.user.id)
        self.assertEqual(rupees(user.withdrawable_balance), 80.0)

        # --- Re-reconciling an already-reconciled sale must be rejected ---
        with self.assertRaises(ValueError):
            recon.reconcile_and_settle(sale1.id, "approved")

    def test_withdrawal_rate_limit(self):
        UserRepository(self.conn).adjust_balance(self.user.id, paise(100))
        wsvc = WithdrawalService(self.conn)
        wsvc.initiate_withdrawal(self.user.id, paise(20))
        with self.assertRaises(PermissionError):
            wsvc.initiate_withdrawal(self.user.id, paise(20))

    def test_withdrawal_rate_limit_after_24h(self):
        UserRepository(self.conn).adjust_balance(self.user.id, paise(100))
        wsvc = WithdrawalService(self.conn)
        past = datetime.now(timezone.utc) - timedelta(hours=25)
        wsvc.initiate_withdrawal(self.user.id, paise(20), now=past)
        # 25 hours later, a new withdrawal should be allowed
        wsvc.initiate_withdrawal(self.user.id, paise(20))

    def test_failed_payout_recovery(self):
        """Question 2: a failed/cancelled/rejected payout must credit the
        amount back and allow immediate re-withdrawal (no 24h wait)."""
        UserRepository(self.conn).adjust_balance(self.user.id, paise(100))
        wsvc = WithdrawalService(self.conn)
        w1 = wsvc.initiate_withdrawal(self.user.id, paise(30))

        user = UserRepository(self.conn).get(self.user.id)
        self.assertEqual(rupees(user.withdrawable_balance), 70.0)

        # Provider webhook says it failed.
        wsvc.update_withdrawal_status(w1.id, "failed")
        user = UserRepository(self.conn).get(self.user.id)
        self.assertEqual(rupees(user.withdrawable_balance), 100.0)  # credited back

        # Duplicate webhook delivery must not double-credit.
        wsvc.update_withdrawal_status(w1.id, "failed")
        user = UserRepository(self.conn).get(self.user.id)
        self.assertEqual(rupees(user.withdrawable_balance), 100.0)

        # User can immediately withdraw again — the 24h limit doesn't apply
        # to a failed-then-recovered withdrawal.
        w2 = wsvc.initiate_withdrawal(self.user.id, paise(30))
        self.assertIsNotNone(w2)

    def test_insufficient_balance_withdrawal_rejected(self):
        wsvc = WithdrawalService(self.conn)
        with self.assertRaises(ValueError):
            wsvc.initiate_withdrawal(self.user.id, paise(50))  # balance is 0


if __name__ == "__main__":
    unittest.main()
