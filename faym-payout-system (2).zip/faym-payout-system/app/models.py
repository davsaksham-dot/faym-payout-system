"""
Domain models (class design).

These are plain dataclasses that map 1:1 to DB rows. Business logic does
NOT live on these classes — it lives in the service layer — so these stay
simple, serializable, and easy to reason about independently of storage.
"""
from dataclasses import dataclass, asdict
from typing import Optional


def rupees(paise: int) -> float:
    """Convert stored paise -> rupees for display in API responses."""
    return round(paise / 100, 2)


def paise(rupees_amount) -> int:
    """Convert incoming rupee amounts -> paise for storage."""
    return round(float(rupees_amount) * 100)


@dataclass
class User:
    id: str
    name: str
    withdrawable_balance: int  # paise
    created_at: str

    def to_dict(self):
        d = asdict(self)
        d["withdrawable_balance"] = rupees(self.withdrawable_balance)
        return d


@dataclass
class Brand:
    id: str
    name: str

    def to_dict(self):
        return asdict(self)


@dataclass
class Sale:
    id: str
    user_id: str
    brand_id: str
    earning: int  # paise
    status: str  # pending | approved | rejected
    advance_payout_status: str  # not_started | processing | paid | failed
    advance_payout_amount: int  # paise
    settlement_status: str  # unsettled | settled
    final_adjustment_amount: Optional[int]  # paise, signed
    created_at: str
    updated_at: str

    ADVANCE_PAYOUT_RATE = 0.10

    def to_dict(self):
        d = asdict(self)
        d["earning"] = rupees(self.earning)
        d["advance_payout_amount"] = rupees(self.advance_payout_amount)
        d["final_adjustment_amount"] = (
            rupees(self.final_adjustment_amount) if self.final_adjustment_amount is not None else None
        )
        return d


@dataclass
class Withdrawal:
    id: str
    user_id: str
    amount: int  # paise
    status: str  # initiated | success | failed | cancelled | rejected
    recovered: int  # 0/1
    created_at: str
    updated_at: str

    def to_dict(self):
        d = asdict(self)
        d["amount"] = rupees(self.amount)
        d["recovered"] = bool(self.recovered)
        return d


@dataclass
class LedgerEntry:
    id: str
    user_id: str
    sale_id: Optional[str]
    withdrawal_id: Optional[str]
    entry_type: str
    amount: int  # signed, paise
    balance_after: int  # paise
    created_at: str

    def to_dict(self):
        d = asdict(self)
        d["amount"] = rupees(self.amount)
        d["balance_after"] = rupees(self.balance_after)
        return d
