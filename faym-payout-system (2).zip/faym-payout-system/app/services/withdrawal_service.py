"""
Withdrawal Service — Business Rule 3 (rate limit) + Question 2 (failed
payout recovery).

Rate limit: a user may have only one withdrawal *in flight or successful*
per rolling 24 hours. A withdrawal that later fails/is cancelled/rejected
does NOT count against this limit once recovered — Question 2 explicitly
requires the recovered amount to be immediately withdrawable again.

Recovery flow: when a withdrawal that already left 'initiated' comes back
as failed/cancelled/rejected (e.g. via a gateway webhook), the amount is
credited back to the user's withdrawable balance exactly once (CAS-guarded
via `recovered` flag) and a `withdrawal_reversal` ledger entry is posted.
"""
from datetime import datetime, timedelta, timezone
from app.db import transaction
from app.repositories.withdrawal_repository import WithdrawalRepository
from app.repositories.user_repository import UserRepository
from app.repositories.ledger_repository import LedgerRepository

RATE_LIMIT_WINDOW = timedelta(hours=24)
TERMINAL_UNSUCCESSFUL_STATUSES = ("failed", "cancelled", "rejected")


def _parse(ts):
    return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)


class WithdrawalService:
    def __init__(self, conn):
        self.conn = conn

    def initiate_withdrawal(self, user_id, amount_paise, now=None):
        custom_now = now is not None  # only used to backdate created_at in tests
        now = now or datetime.now(timezone.utc)
        if amount_paise <= 0:
            raise ValueError("Withdrawal amount must be positive")

        wd_repo = WithdrawalRepository(self.conn)
        user_repo = UserRepository(self.conn)
        ledger_repo = LedgerRepository(self.conn)

        with transaction(self.conn):
            last = wd_repo.most_recent_rate_limited(user_id)
            if last is not None:
                elapsed = now - _parse(last.created_at)
                if elapsed < RATE_LIMIT_WINDOW:
                    retry_after = RATE_LIMIT_WINDOW - elapsed
                    raise PermissionError(
                        f"Only one withdrawal is allowed every 24 hours. "
                        f"Try again in {retry_after}."
                    )

            balance = user_repo.get_balance_for_update(user_id)
            if amount_paise > balance:
                raise ValueError(
                    f"Insufficient withdrawable balance: requested {amount_paise}, available {balance}"
                )

            created_at = now.strftime("%Y-%m-%dT%H:%M:%S.%fZ") if custom_now else None
            withdrawal = wd_repo.create(user_id, amount_paise, created_at=created_at)
            new_balance = user_repo.adjust_balance(user_id, -amount_paise)
            ledger_repo.add(
                user_id=user_id,
                entry_type="withdrawal_debit",
                amount_paise=-amount_paise,
                balance_after_paise=new_balance,
                withdrawal_id=withdrawal.id,
            )
            return withdrawal

    def update_withdrawal_status(self, withdrawal_id, new_status):
        """
        Called by the payout-provider webhook (or a manual admin action)
        once the withdrawal's real-world outcome is known.
        """
        if new_status not in ("success", "failed", "cancelled", "rejected"):
            raise ValueError(f"Invalid withdrawal status: {new_status}")

        wd_repo = WithdrawalRepository(self.conn)
        user_repo = UserRepository(self.conn)
        ledger_repo = LedgerRepository(self.conn)

        with transaction(self.conn):
            withdrawal = wd_repo.get(withdrawal_id)
            if withdrawal is None:
                raise ValueError(f"Withdrawal {withdrawal_id} not found")

            moved = wd_repo.try_update_status(withdrawal_id, new_status, from_statuses=["initiated"])
            if not moved:
                return {"withdrawal_id": withdrawal_id, "outcome": "ignored_not_in_initiated_state"}

            if new_status in TERMINAL_UNSUCCESSFUL_STATUSES:
                # Question 2: credit the failed amount back & allow re-withdrawal.
                recovered = wd_repo.try_mark_recovered(withdrawal_id)
                if recovered:
                    new_balance = user_repo.adjust_balance(withdrawal.user_id, withdrawal.amount)
                    ledger_repo.add(
                        user_id=withdrawal.user_id,
                        entry_type="withdrawal_reversal",
                        amount_paise=withdrawal.amount,
                        balance_after_paise=new_balance,
                        withdrawal_id=withdrawal_id,
                    )
                return {"withdrawal_id": withdrawal_id, "outcome": f"{new_status}_recovered"}

            return {"withdrawal_id": withdrawal_id, "outcome": "success"}
