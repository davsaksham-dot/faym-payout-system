"""
Advance Payout Service — Business Rule 1.

Every PENDING sale is eligible for a one-time advance payout of 10% of
its earnings. This is meant to run as a repeatable batch job (cron /
queue worker). Idempotency is the central concern here: the job may be
retried, may run concurrently across multiple workers, or may be re-run
after a partial failure — and a sale must NEVER receive two successful
advance payouts.

Idempotency strategy: a compare-and-swap (CAS) UPDATE
(`not_started -> processing`) claims a sale for exactly one worker.
Only the worker that wins the CAS proceeds to call the gateway and
credit the user. Losers simply skip the sale.
"""
from app.db import transaction
from app.repositories.sale_repository import SaleRepository
from app.repositories.user_repository import UserRepository
from app.repositories.ledger_repository import LedgerRepository


class AdvancePayoutService:
    def __init__(self, conn, gateway):
        self.conn = conn
        self.gateway = gateway

    def run_batch(self):
        """
        Process all pending sales that haven't had an advance payout
        attempted yet. Each sale is processed in its own transaction so
        that one failure can't roll back or block the others.
        """
        sales = SaleRepository(self.conn).list_eligible_for_advance()
        results = []
        for sale in sales:
            results.append(self.process_one(sale.id))
        return results

    def process_one(self, sale_id):
        sale_repo = SaleRepository(self.conn)
        user_repo = UserRepository(self.conn)
        ledger_repo = LedgerRepository(self.conn)

        with transaction(self.conn):
            # CAS: only one caller can move this sale into 'processing'.
            won = sale_repo.try_mark_advance_processing(sale_id)
            if not won:
                return {"sale_id": sale_id, "outcome": "skipped_already_claimed"}

            sale = sale_repo.get(sale_id)
            amount_paise = round(sale.earning * sale.ADVANCE_PAYOUT_RATE)

            success = self.gateway.transfer(sale.user_id, amount_paise, reference=f"advance:{sale_id}")

            if success:
                sale_repo.finalize_advance_payout(sale_id, success=True, amount_paise=amount_paise)
                new_balance = user_repo.adjust_balance(sale.user_id, amount_paise)
                ledger_repo.add(
                    user_id=sale.user_id,
                    entry_type="advance_payout",
                    amount_paise=amount_paise,
                    balance_after_paise=new_balance,
                    sale_id=sale_id,
                )
                return {"sale_id": sale_id, "outcome": "paid", "amount_paise": amount_paise}
            else:
                sale_repo.finalize_advance_payout(sale_id, success=False)
                # Make it eligible again so the NEXT batch run retries it —
                # note this is still safe: 'not_started' only reopens a sale
                # that never had a successful transfer.
                sale_repo.reset_advance_for_retry(sale_id)
                return {"sale_id": sale_id, "outcome": "failed_will_retry"}
