"""
Reconciliation Service — Business Rule 2 (Final Payout Calculation).

    Approved sale -> final_adjustment = earning - advance_paid   (user gets the rest)
    Rejected sale -> final_adjustment = -advance_paid            (claw back the advance)

Reconciliation (admin decides approved/rejected) and settlement (computing
& applying the money movement) are modelled as two separate, independently
idempotent steps:

  1. `reconcile_sale`  — CAS pending -> approved/rejected. Called directly
     by an admin action / API call.
  2. `settle_sale`     — CAS unsettled -> settled, computes the adjustment
     and posts it to the ledger. Can be called immediately after step 1,
     or picked up later by a background sweep (`list_unsettled_reconciled`)
     for sales whose settlement step previously crashed.

Splitting them this way means a crash between "admin approved it" and
"money moved" is recoverable by re-running settlement, without ever
double-reconciling or double-paying.
"""
from app.db import transaction
from app.repositories.sale_repository import SaleRepository
from app.repositories.user_repository import UserRepository
from app.repositories.ledger_repository import LedgerRepository


class ReconciliationService:
    def __init__(self, conn):
        self.conn = conn

    def reconcile_and_settle(self, sale_id, decision):
        """Convenience wrapper: reconcile then immediately settle, atomically."""
        if decision not in ("approved", "rejected"):
            raise ValueError("decision must be 'approved' or 'rejected'")

        sale_repo = SaleRepository(self.conn)
        with transaction(self.conn):
            won = sale_repo.try_reconcile(sale_id, decision)
            if not won:
                sale = sale_repo.get(sale_id)
                if sale is None:
                    raise ValueError(f"Sale {sale_id} not found")
                raise ValueError(
                    f"Sale {sale_id} is not pending (current status: {sale.status}); "
                    f"cannot reconcile again."
                )
            return self._settle_locked(sale_id)

    def settle_unsettled(self):
        """Background sweep: settle any reconciled sale that hasn't been
        settled yet (e.g. because a previous run crashed after step 1)."""
        sale_repo = SaleRepository(self.conn)
        pending = sale_repo.list_unsettled_reconciled()
        return [self.settle_sale(s.id) for s in pending]

    def settle_sale(self, sale_id):
        with transaction(self.conn):
            return self._settle_locked(sale_id)

    def _settle_locked(self, sale_id):
        """Must be called from within an open transaction."""
        sale_repo = SaleRepository(self.conn)
        user_repo = UserRepository(self.conn)
        ledger_repo = LedgerRepository(self.conn)

        sale = sale_repo.get(sale_id)
        if sale is None:
            raise ValueError(f"Sale {sale_id} not found")
        if sale.status not in ("approved", "rejected"):
            return {"sale_id": sale_id, "outcome": "not_reconciled_yet"}

        if sale.status == "approved":
            adjustment = sale.earning - sale.advance_payout_amount
        else:  # rejected
            adjustment = -sale.advance_payout_amount

        won = sale_repo.try_mark_settled(sale_id, adjustment)
        if not won:
            return {"sale_id": sale_id, "outcome": "already_settled"}

        new_balance = user_repo.adjust_balance(sale.user_id, adjustment)
        ledger_repo.add(
            user_id=sale.user_id,
            entry_type="final_adjustment",
            amount_paise=adjustment,
            balance_after_paise=new_balance,
            sale_id=sale_id,
        )
        return {"sale_id": sale_id, "outcome": "settled", "adjustment_paise": adjustment}
