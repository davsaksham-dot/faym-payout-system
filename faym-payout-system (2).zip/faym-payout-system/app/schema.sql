-- ============================================================
-- Faym Affiliate Payout System — Schema
-- All monetary values are stored as INTEGER PAISE (rupees * 100)
-- to avoid floating point rounding errors in financial calculations.
-- ============================================================

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id                     TEXT PRIMARY KEY,
    name                   TEXT NOT NULL,
    withdrawable_balance   INTEGER NOT NULL DEFAULT 0,   -- paise, can go negative (see README: negative balance)
    created_at             TEXT NOT NULL DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS brands (
    id     TEXT PRIMARY KEY,
    name   TEXT NOT NULL
);

-- One row per affiliate sale.
CREATE TABLE IF NOT EXISTS sales (
    id                      TEXT PRIMARY KEY,
    user_id                 TEXT NOT NULL REFERENCES users(id),
    brand_id                TEXT NOT NULL REFERENCES brands(id),
    earning                 INTEGER NOT NULL,             -- paise
    status                  TEXT NOT NULL DEFAULT 'pending'
                                CHECK (status IN ('pending','approved','rejected')),

    -- Advance payout tracking (Business Rule 1).
    -- 'not_started' -> 'processing' -> 'paid' | 'failed'
    -- The not_started -> processing transition is a compare-and-swap (CAS),
    -- guaranteeing a sale can NEVER receive two successful advance payouts
    -- even if the batch job runs concurrently / is retried.
    advance_payout_status   TEXT NOT NULL DEFAULT 'not_started'
                                CHECK (advance_payout_status IN ('not_started','processing','paid','failed')),
    advance_payout_amount   INTEGER NOT NULL DEFAULT 0,   -- paise actually paid out (0 until paid)

    -- Final settlement tracking (Business Rule 2).
    -- CAS-guarded the same way, so reconciliation can never be double-applied.
    settlement_status       TEXT NOT NULL DEFAULT 'unsettled'
                                CHECK (settlement_status IN ('unsettled','settled')),
    final_adjustment_amount INTEGER,                       -- paise, signed, filled once settled

    created_at              TEXT NOT NULL DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at              TEXT NOT NULL DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_sales_user           ON sales(user_id);
CREATE INDEX IF NOT EXISTS idx_sales_status          ON sales(status);
CREATE INDEX IF NOT EXISTS idx_sales_advance_status  ON sales(advance_payout_status);
CREATE INDEX IF NOT EXISTS idx_sales_settlement      ON sales(settlement_status);

-- One row per user withdrawal attempt (Business Rule 3 + Q2 recovery flow).
CREATE TABLE IF NOT EXISTS withdrawals (
    id           TEXT PRIMARY KEY,
    user_id      TEXT NOT NULL REFERENCES users(id),
    amount       INTEGER NOT NULL,             -- paise, always positive
    status       TEXT NOT NULL DEFAULT 'initiated'
                    CHECK (status IN ('initiated','success','failed','cancelled','rejected')),
    recovered    INTEGER NOT NULL DEFAULT 0,   -- 0/1 — whether a failed/cancelled/rejected amount
                                                -- has already been re-credited (idempotency guard)
    created_at   TEXT NOT NULL DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at   TEXT NOT NULL DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_user_created ON withdrawals(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status       ON withdrawals(status);

-- Append-only ledger. Every balance-changing event writes exactly one row here.
-- This is the audit trail / source of truth used to reconcile user balances.
CREATE TABLE IF NOT EXISTS ledger_entries (
    id             TEXT PRIMARY KEY,
    user_id        TEXT NOT NULL REFERENCES users(id),
    sale_id        TEXT REFERENCES sales(id),
    withdrawal_id  TEXT REFERENCES withdrawals(id),
    entry_type     TEXT NOT NULL
                      CHECK (entry_type IN (
                        'advance_payout',        -- +amount, sale-linked
                        'final_adjustment',      -- +/-amount, sale-linked
                        'withdrawal_debit',      -- -amount, withdrawal-linked
                        'withdrawal_reversal'    -- +amount, withdrawal-linked
                      )),
    amount         INTEGER NOT NULL,   -- signed, paise
    balance_after  INTEGER NOT NULL,   -- user's withdrawable_balance right after this entry
    created_at     TEXT NOT NULL DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_ledger_sale ON ledger_entries(sale_id);
