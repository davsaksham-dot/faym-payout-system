import uuid
from app.models import LedgerEntry


class LedgerRepository:
    def __init__(self, conn):
        self.conn = conn

    def add(self, user_id, entry_type, amount_paise, balance_after_paise, sale_id=None, withdrawal_id=None, id=None):
        lid = id or str(uuid.uuid4())
        self.conn.execute(
            """INSERT INTO ledger_entries (id, user_id, sale_id, withdrawal_id, entry_type, amount, balance_after)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (lid, user_id, sale_id, withdrawal_id, entry_type, amount_paise, balance_after_paise),
        )
        return self.get(lid)

    def get(self, ledger_id):
        row = self.conn.execute("SELECT * FROM ledger_entries WHERE id = ?", (ledger_id,)).fetchone()
        return LedgerEntry(**dict(row)) if row else None

    def list_by_user(self, user_id):
        rows = self.conn.execute(
            "SELECT * FROM ledger_entries WHERE user_id = ? ORDER BY created_at", (user_id,)
        ).fetchall()
        return [LedgerEntry(**dict(r)) for r in rows]
