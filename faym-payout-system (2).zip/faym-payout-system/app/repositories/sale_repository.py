import uuid
from app.models import Sale


class SaleRepository:
    def __init__(self, conn):
        self.conn = conn

    def create(self, user_id, brand_id, earning_paise, status="pending", id=None):
        sid = id or str(uuid.uuid4())
        self.conn.execute(
            """INSERT INTO sales (id, user_id, brand_id, earning, status)
               VALUES (?, ?, ?, ?, ?)""",
            (sid, user_id, brand_id, earning_paise, status),
        )
        return self.get(sid)

    def get(self, sale_id):
        row = self.conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
        return Sale(**dict(row)) if row else None

    def list_all(self):
        rows = self.conn.execute("SELECT * FROM sales ORDER BY created_at").fetchall()
        return [Sale(**dict(r)) for r in rows]

    def list_by_user(self, user_id):
        rows = self.conn.execute(
            "SELECT * FROM sales WHERE user_id = ? ORDER BY created_at", (user_id,)
        ).fetchall()
        return [Sale(**dict(r)) for r in rows]

    def list_eligible_for_advance(self):
        """Pending sales that have never had a successful (or in-flight) advance payout."""
        rows = self.conn.execute(
            "SELECT * FROM sales WHERE status = 'pending' AND advance_payout_status = 'not_started'"
        ).fetchall()
        return [Sale(**dict(r)) for r in rows]

    # ---- Compare-and-swap transitions (idempotency guards) ----

    def try_mark_advance_processing(self, sale_id):
        """CAS: not_started -> processing. Returns True iff this call won the race."""
        cur = self.conn.execute(
            """UPDATE sales SET advance_payout_status = 'processing', updated_at = STRFTIME('%Y-%m-%dT%H:%M:%fZ','now')
               WHERE id = ? AND advance_payout_status = 'not_started'""",
            (sale_id,),
        )
        return cur.rowcount == 1

    def finalize_advance_payout(self, sale_id, success, amount_paise=0):
        status = "paid" if success else "failed"
        self.conn.execute(
            """UPDATE sales SET advance_payout_status = ?, advance_payout_amount = ?,
               updated_at = STRFTIME('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?""",
            (status, amount_paise if success else 0, sale_id),
        )

    def reset_advance_for_retry(self, sale_id):
        """A failed advance payout should be retryable on the next job run."""
        self.conn.execute(
            """UPDATE sales SET advance_payout_status = 'not_started'
               WHERE id = ? AND advance_payout_status = 'failed'""",
            (sale_id,),
        )

    def list_unsettled_reconciled(self):
        """Sales that have been reconciled (approved/rejected) but not yet settled."""
        rows = self.conn.execute(
            "SELECT * FROM sales WHERE status IN ('approved','rejected') AND settlement_status = 'unsettled'"
        ).fetchall()
        return [Sale(**dict(r)) for r in rows]

    def try_reconcile(self, sale_id, new_status):
        """CAS: only move a sale out of 'pending' once. Prevents an admin
        double-click (or duplicate webhook) from reconciling a sale twice."""
        cur = self.conn.execute(
            """UPDATE sales SET status = ?, updated_at = STRFTIME('%Y-%m-%dT%H:%M:%fZ','now')
               WHERE id = ? AND status = 'pending'""",
            (new_status, sale_id),
        )
        return cur.rowcount == 1

    def try_mark_settled(self, sale_id, final_adjustment_amount):
        """CAS: unsettled -> settled, so final payout math is applied exactly once."""
        cur = self.conn.execute(
            """UPDATE sales SET settlement_status = 'settled', final_adjustment_amount = ?,
               updated_at = STRFTIME('%Y-%m-%dT%H:%M:%fZ','now')
               WHERE id = ? AND settlement_status = 'unsettled'""",
            (final_adjustment_amount, sale_id),
        )
        return cur.rowcount == 1
