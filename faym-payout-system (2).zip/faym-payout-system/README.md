# Faym — User Payout Management System (Low-Level Design)

A working LLD implementation for the affiliate-sale payout system described
in the SDE Intern assignment: advance payouts, reconciliation-driven final
settlement, withdrawal rate-limiting, and failed-payout recovery.

**Stack:** Python 3, Flask (REST API), SQLite (storage). No external services
required — clone and run.

---

## 1. Quick start

```bash
pip install -r requirements.txt
python main.py            # seeds sample data + starts API on :5000
```

```bash
# in another shell
python -m unittest tests.test_scenario -v
```

The test suite (`tests/test_scenario.py`) reproduces the assignment's own
worked example (3 sales of ₹40, one rejected + two approved) end-to-end
through the real services and asserts the numbers match exactly.

---

## 2. Problem restated, precisely

1. A sale is created as **pending**.
2. A batch job pays an **advance** = 10% of earnings to every pending sale,
   exactly once per sale — ever, no matter how many times the job runs.
3. An admin later **reconciles** each sale to `approved` or `rejected`.
4. On reconciliation, a **final adjustment** is computed and posted:
   - `approved` → `adjustment = earning − advance_paid` (pay the rest)
   - `rejected` → `adjustment = −advance_paid` (claw back the advance)
5. A user may only make **one withdrawal every 24 hours**.
6. If a withdrawal later comes back **failed / cancelled / rejected**, the
   amount is credited back to the user's balance and can be withdrawn again
   immediately (Question 2) — the 24h rule does not block that retry.

---

## 3. Architecture (Low-Level Design)

```
┌─────────────┐     ┌───────────────────────┐     ┌──────────────────────┐
│   API layer  │────▶│      Service layer     │────▶│   Repository layer    │
│  (Flask, thin│     │  (all business rules,  │     │ (SQL + CAS updates,   │
│  controllers)│     │   transactions live    │     │  one class per table) │
└─────────────┘     │   here)                │     └──────────────────────┘
                     └───────────────────────┘                │
                                                                ▼
                                                         ┌─────────────┐
                                                         │   SQLite    │
                                                         └─────────────┘
```

- **`app/models.py`** — plain dataclasses (`User`, `Sale`, `Withdrawal`,
  `LedgerEntry`). No business logic; just data + `to_dict()` for
  serialization. Money is stored as **integer paise** everywhere internally
  and only converted to rupees at the API boundary, to avoid floating-point
  rounding bugs in financial math.
- **`app/repositories/*`** — one class per table. Every state transition
  that must be idempotent is a **compare-and-swap (CAS) UPDATE**
  (`UPDATE ... WHERE id=? AND status='expected_status'`, checking
  `rowcount==1`) rather than a read-then-write, so it's safe under retries
  and concurrent callers without needing a distributed lock.
- **`app/services/*`** — the actual business rules, one file per concern:
  - `advance_payout_service.py` — Business Rule 1
  - `reconciliation_service.py` — Business Rule 2 / final payout calculation
  - `withdrawal_service.py` — Business Rule 3 + Question 2 (recovery)
  - `payment_gateway.py` — mock external payout provider (swappable)
- **`app/api.py`** — Flask routes; pure controllers, no logic.

### Why a layered/repository design (trade-off)

A simpler script could inline SQL directly in route handlers. The
repository/service split costs a bit of boilerplate but buys:
- Idempotency guarantees are centralized in one place per entity, instead
  of being re-implemented (and possibly forgotten) in every caller.
- The service layer is trivially testable without spinning up Flask
  (see `tests/test_scenario.py`, which never touches `app/api.py`).
- SQLite → Postgres migration later only touches `app/db.py`.

---

## 4. Database schema

See `app/schema.sql` for the full DDL with comments. Summary:

```
users            (id, name, withdrawable_balance, created_at)
brands           (id, name)
sales            (id, user_id → users, brand_id → brands, earning,
                   status,                     -- pending | approved | rejected
                   advance_payout_status,      -- not_started | processing | paid | failed
                   advance_payout_amount,
                   settlement_status,          -- unsettled | settled
                   final_adjustment_amount,
                   created_at, updated_at)
withdrawals      (id, user_id → users, amount, status, recovered,
                   created_at, updated_at)      -- status: initiated | success | failed | cancelled | rejected
ledger_entries   (id, user_id → users, sale_id?, withdrawal_id?,
                   entry_type,                 -- advance_payout | final_adjustment |
                                                --   withdrawal_debit | withdrawal_reversal
                   amount, balance_after, created_at)
```

**Relationships:** `users 1—N sales`, `users 1—N withdrawals`,
`users 1—N ledger_entries`; `sales` and `withdrawals` each optionally link
back into `ledger_entries` (nullable FKs) so every balance-changing event
has full provenance.

`ledger_entries` is the append-only audit trail — `users.withdrawable_balance`
is a materialized, denormalized cache of "sum of all ledger entries for that
user" kept in sync transactionally. This is a deliberate trade-off:
denormalizing the balance makes reads (`GET /users/:id`) O(1) instead of
requiring a `SUM()` over the ledger on every request, at the cost of having
to keep the two in sync (mitigated by always updating both inside the same
DB transaction).

---

## 5. Idempotency — the core design problem

Both Q1's advance-payout job and Q2's recovery flow are described as
processes that might run more than once (the doc explicitly says "even if
the advance payout job runs multiple times"). Two independent mechanisms
handle this:

1. **State-machine CAS updates.** Every irreversible transition
   (`not_started→processing`, `pending→approved/rejected`,
   `unsettled→settled`, `initiated→failed`, `recovered=0→1`) is a single
   `UPDATE ... WHERE <current-state>` statement. If two workers race, only
   one `UPDATE` affects a row (`rowcount==1`); the other sees `rowcount==0`
   and simply no-ops. No `SELECT`-then-`UPDATE` window exists where a race
   can slip through.
2. **`BEGIN IMMEDIATE` transactions** (`app/db.py`) around every write path,
   so SQLite's writer lock is acquired up front rather than lazily —
   preventing two "read passed, both proceed to write" races that a
   deferred transaction would otherwise allow. In Postgres/MySQL this maps
   to `SELECT ... FOR UPDATE` or an equivalent optimistic version column.

---

## 6. API / endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/users` | Create a user |
| `GET` | `/users/:id` | Get user + current balance |
| `GET` | `/users/:id/transactions` | Full ledger for a user (audit trail) |
| `POST` | `/sales` | Create a sale (`status=pending`) |
| `GET` | `/sales/:id` | Get one sale |
| `GET` | `/users/:id/sales` | List a user's sales |
| `POST` | `/admin/sales/:id/reconcile` | `{decision: "approved"\|"rejected"}` → reconciles + settles |
| `POST` | `/jobs/advance-payout/run` | Trigger the advance-payout batch job (cron/queue in prod) |
| `POST` | `/jobs/settlement/run` | Sweep any reconciled-but-unsettled sales |
| `POST` | `/users/:id/withdrawals` | `{amount}` → initiate a withdrawal (enforces 24h rule + balance check) |
| `GET` | `/users/:id/withdrawals` | List a user's withdrawals |
| `POST` | `/webhooks/withdrawals/:id/status` | `{status}` → provider callback (`success`\|`failed`\|`cancelled`\|`rejected`); triggers recovery |
| `GET` | `/health` | Liveness check |

All amounts in request/response bodies are **rupees** (e.g. `{"amount": 40}`);
conversion to/from internal paise happens at the API boundary
(`app/models.py: paise()` / `rupees()`).

---

## 7. Edge cases & failure scenarios handled

- **Advance-payout job re-run / concurrent workers** → CAS on
  `advance_payout_status` guarantees at most one successful payout per sale
  (tested in `test_worked_example_from_assignment`).
- **Gateway transfer fails during advance payout** → sale is reset to
  `not_started` so the *next* job run retries it, instead of being stuck
  forever in `failed` or silently skipped.
- **Admin reconciles the same sale twice** (double-click, retried request,
  duplicate webhook) → CAS on `sales.status` (`pending→…`) rejects the
  second attempt with a 409 and a clear error.
- **Settlement crashes after reconciliation but before the ledger write** →
  `settlement_status` stays `unsettled`; `POST /jobs/settlement/run` (or any
  later `reconcile_and_settle`/`settle_sale` call) will safely finish the job
  without re-reconciling.
- **Rejected sale where the advance was never actually paid yet**
  (`advance_payout_amount = 0`) → adjustment is correctly `0`, not a
  spurious negative number.
- **Withdrawal requested for more than the current balance** → rejected
  with `400` before any row is written.
- **Second withdrawal within 24h** → rejected with `429` and a
  `retry_after` duration in the error message.
- **A failed/cancelled/rejected withdrawal must not block re-withdrawal**
  → recovered withdrawals are excluded from the 24h rate-limit check
  (`most_recent_rate_limited` only considers `initiated`/`success` rows).
- **Duplicate failure webhook for the same withdrawal** → `recovered` flag
  is itself CAS-guarded (`recovered=0→1`), so the amount is credited back
  **exactly once** even if the provider sends the callback twice.
- **Withdrawal status update for a withdrawal that's already terminal**
  (e.g. a stray webhook after it was already marked `success`) → CAS on
  `withdrawals.status` (`from initiated only`) makes this a no-op instead
  of double-crediting or double-debiting.
- **Negative running balance is allowed by design** — see trade-off below.

### Trade-off: allowing a negative withdrawable balance

If a sale is rejected *after* its advance was paid, and the user has since
withdrawn everything else, the `−advance_paid` adjustment can push their
balance negative. Two options were considered:
- **Clamp at zero and write off the loss** — simpler, but silently absorbs
  a cost Faym is owed, and loses the audit trail of what's actually owed.
- **Allow negative balances (chosen)** — the ledger stays fully accurate;
  a negative balance is real "debt" that nets out against the user's
  future advance payouts/settlements before any further withdrawal is
  permitted (since `initiate_withdrawal` checks `amount ≤ balance`, a
  negative balance simply blocks withdrawals until it's paid down).
  This mirrors how most affiliate platforms actually handle clawbacks.

---

## 8. What's deliberately out of scope / left simple

- Authentication/authorization on the API (would sit in front of these
  routes; not core to the payout logic being demonstrated).
- A real payment gateway integration — `payment_gateway.py` is a clean seam
  for one; both the advance-payout and withdrawal flows already read their
  gateway result as a return value or a webhook, so swapping in a real,
  async, webhook-driven provider requires no change to the CAS-guarded
  repository/service logic.
- Multi-currency — everything assumes INR/paise.
- Horizontal scaling of SQLite itself — the CAS + `BEGIN IMMEDIATE`
  discipline is what would carry over to Postgres for a multi-instance
  deployment; SQLite here is purely for zero-setup portability of the demo.

---

## 9. Project layout

```
faym-payout-system/
├── README.md
├── requirements.txt
├── main.py                        # seeds data + runs the Flask server
├── app/
│   ├── db.py                      # connection + transaction helper
│   ├── schema.sql                 # full DDL
│   ├── models.py                  # dataclasses + paise/rupee conversion
│   ├── api.py                     # Flask routes (thin controllers)
│   ├── repositories/
│   │   ├── user_repository.py
│   │   ├── sale_repository.py
│   │   ├── withdrawal_repository.py
│   │   └── ledger_repository.py
│   └── services/
│       ├── advance_payout_service.py
│       ├── reconciliation_service.py
│       ├── withdrawal_service.py
│       └── payment_gateway.py
└── tests/
    └── test_scenario.py           # reproduces the assignment's worked example
```
